#Esta guía explica los conceptos fundamentales y las prácticas recomendadas para trabajar con archivos 
#en Python. Se abordan temas como abrir, leer, escribir y cerrar archivos, así como la gestión de errores 
#y el manejo de archivos con diferentes modos.