#practicas recomendadas
# 1. utilizar el bloque with: asegura que el archivo se cierra automaticamente
#
# 2. manejo de excepciones: siempre utiliza bloques try-except para evitar
#    que tu programa falle por errores inesperados
#
# 3. verifica la existencia de archivos: antes de abrir un archivo, verifica 
#    si existe usando el modulo os: