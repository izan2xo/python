#Ejecuta un bloque de código mientras una condición sea verdadera.
#Es útil cuando no sabes de antemano cuántas veces necesitas iterar.

contador = 0
while contador < 5:
    print(contador)
    contador += 1
    