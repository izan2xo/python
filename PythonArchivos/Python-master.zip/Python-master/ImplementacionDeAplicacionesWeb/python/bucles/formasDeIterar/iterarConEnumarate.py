frutas = ["manzana", "banana", "cereza"]
for indice, fruta in enumerate(frutas):
    print(f"índice:{indice},Fruta:{fruta}")