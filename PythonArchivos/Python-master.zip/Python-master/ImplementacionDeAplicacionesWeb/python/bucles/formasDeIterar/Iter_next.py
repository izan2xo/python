frutas = ["manzana", "banana", "cereza"]
iterador = iter(frutas)

print(iterador)

print(next(iterador))
print(next(iterador))