#Es una combinación de bucles dentro de otros bucles.
#Puede ser un for dentro de un for, un while dentro de un while, o combinaciones de ambos.

for i in range(3):
    for j in range(2):
        print(f"i:{i},j:{j}")
        

