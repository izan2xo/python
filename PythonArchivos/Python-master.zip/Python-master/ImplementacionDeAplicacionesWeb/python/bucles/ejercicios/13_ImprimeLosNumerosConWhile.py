numero = 0

while numero < 10:
    numero += 1
    print(numero)