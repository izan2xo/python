numeros = [10, 15, 20, 25, 30]
print(numeros)
pares = []
print(pares)

for numero in numeros:
    if numero % 2 == 0:
        pares.append(numero)
        print(pares)