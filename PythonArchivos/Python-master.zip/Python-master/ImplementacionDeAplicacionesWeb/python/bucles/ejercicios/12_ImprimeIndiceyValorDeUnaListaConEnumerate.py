frutas = ["manzana", "banana", "pera"]

for indice, valor in enumerate(frutas, start=1):
    print(f"Indice: {indice}, valor: {valor}")
