nombres = ["ana", "luis", "carlos"]

for nombre in nombres:
    print(nombre.upper())