contraseña = "python123"

while True:
    password = input("escribe la contraseña: ")
    if password == "python123":
        print("contraseña correcta")
        break
    print("contraseña incorrecta. vuelva a intentar")
