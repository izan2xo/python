productos = {"manzana": 1.5, "banana": 0.8, "leche": 2.3}

for clave, valor in productos.items():
    print(f"clave {clave} = valor {valor}")
    