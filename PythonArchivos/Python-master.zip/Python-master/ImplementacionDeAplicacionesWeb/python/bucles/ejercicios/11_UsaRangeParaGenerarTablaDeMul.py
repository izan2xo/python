multiplicador = 0
multiplicando = 2

for resultado in range(0, 100, multiplicando):
    print(f"5 x {multiplicador} = {resultado}")
    multiplicador += 1