cadena = "Hola Mundo"

cadena_invertida = ""

for letra in cadena:
    cadena_invertida = letra + cadena_invertida
    
print(cadena_invertida)