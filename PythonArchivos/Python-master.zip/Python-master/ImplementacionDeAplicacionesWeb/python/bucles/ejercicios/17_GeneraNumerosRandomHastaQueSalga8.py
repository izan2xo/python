import random

numero = 0

while True:
    numero = random.randint(1, 10)
    print(numero)
    if numero == 8:
        break