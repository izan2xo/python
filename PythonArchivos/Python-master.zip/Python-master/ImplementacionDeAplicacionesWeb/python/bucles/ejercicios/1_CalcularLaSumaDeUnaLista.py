numeros = [1, 2, 3, 4, 5]

suma = 0

for i in numeros:
    print(f"la suma de {suma} mas {i} es {suma + i}")
    suma += i
