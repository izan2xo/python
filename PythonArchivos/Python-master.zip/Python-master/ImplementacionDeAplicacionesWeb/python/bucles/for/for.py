#Se utiliza para iterar sobre una secuencia (listas, tuplas, cadenas, rangos, etc.).
#Es útil cuando sabes cuántas iteraciones necesitas.

#iterando sobre una lista
for elemento in [1, 2, 3, 4]:
    print(elemento)

for i in range(5):
    print(i)