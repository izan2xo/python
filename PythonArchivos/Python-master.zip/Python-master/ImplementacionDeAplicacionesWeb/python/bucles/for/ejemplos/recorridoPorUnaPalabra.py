palabra = "Python"
numero = 1

for letra in palabra:
    print(f"la letra {letra} esta en la posicion {numero}")
    numero += 1 