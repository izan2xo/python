frutas = ["manzana", "banana", "cereza", "durazno"]

for fruta in frutas:
    print(f"me gusta la {fruta}") 