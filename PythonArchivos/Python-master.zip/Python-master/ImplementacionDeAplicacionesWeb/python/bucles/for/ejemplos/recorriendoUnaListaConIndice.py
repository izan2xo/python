nombres = ["Ana", "Luis", "Carlos"]

for indice, nombre in enumerate(nombres):
    print(f"índice:{indice}, Nombre:{nombre}")
    