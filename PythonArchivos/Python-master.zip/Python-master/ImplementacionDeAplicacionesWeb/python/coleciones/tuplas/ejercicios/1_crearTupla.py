ciudades = ("Madrid", "Barcelona", "Valencia")

print(ciudades)