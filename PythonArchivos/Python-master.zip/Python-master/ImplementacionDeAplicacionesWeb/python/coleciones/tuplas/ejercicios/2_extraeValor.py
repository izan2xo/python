numeros = (100, 200, 300)

print(numeros[1])