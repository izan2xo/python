miTupla = (1, 2, 3, 4, 5)
print(miTupla)

#concatenar tuplas
nuevaTupla = miTupla + (6, 7, 8)
print(nuevaTupla)

#repetir una tupla
repetida = miTupla * 2
print(repetida)