colores = ("rojo", "verde", "azul")

ultimo_color = colores[-1]

print(ultimo_color)