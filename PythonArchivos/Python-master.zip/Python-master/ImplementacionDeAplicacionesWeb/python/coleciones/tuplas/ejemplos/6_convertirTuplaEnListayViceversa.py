miTupla = (1, 2, 3, 4, 5)
print(miTupla)

#para convertit una tupla en una lista
nuevaLista = list(miTupla)
print(nuevaLista)

#para convertir una lista en tupla
nuevaTupla = tuple(nuevaLista)
print(nuevaTupla)