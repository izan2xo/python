miTupla = (1, 2, 3, 4, 5)
print(miTupla)

#puedes asignar los elementos a una tupla de variables directamente
a, b, c, d, e = miTupla
print(a, b, c, d, e)