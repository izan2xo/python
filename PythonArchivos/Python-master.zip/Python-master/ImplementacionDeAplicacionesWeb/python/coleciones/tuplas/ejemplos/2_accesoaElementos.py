miTupla = (1, 2, 3, 4, 5)
print(miTupla)

#acceso por indice
primerElemento = miTupla[0]
print(primerElemento)

#rebanando (slicing)
subTupla = miTupla[1:3]
print(subTupla)