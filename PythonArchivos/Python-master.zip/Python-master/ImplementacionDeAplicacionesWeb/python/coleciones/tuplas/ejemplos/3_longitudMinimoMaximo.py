miTupla = (1, 2, 3, 4, 5)
print(miTupla)

#devuelve la longitud de la tupla
longitud = len(miTupla)
print(longitud)

#devuelve el valor minimo de la tupla
minimo = min(miTupla)
print(minimo)

#devuelve el valor maximo de la tupla
maximo = max(miTupla)
print(maximo)

