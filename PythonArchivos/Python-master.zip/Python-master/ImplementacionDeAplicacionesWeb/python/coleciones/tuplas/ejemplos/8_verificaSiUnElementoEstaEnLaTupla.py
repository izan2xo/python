miTupla = (1, 2, 3, 4, 5)
print(miTupla)

#usando el operador in
existe = 3 in miTupla
print(existe)