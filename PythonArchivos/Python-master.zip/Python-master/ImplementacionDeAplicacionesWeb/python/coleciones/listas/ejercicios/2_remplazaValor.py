frutas = ["manzana", "pera", "naranja"]
print(frutas)

frutas[1] = "uva"
print(frutas)