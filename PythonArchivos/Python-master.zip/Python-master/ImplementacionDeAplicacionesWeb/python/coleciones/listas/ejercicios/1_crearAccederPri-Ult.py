numeros = [1, 2, 3, 4, 5]

print(numeros[0], numeros[4])
print(numeros[-5], numeros[-1])