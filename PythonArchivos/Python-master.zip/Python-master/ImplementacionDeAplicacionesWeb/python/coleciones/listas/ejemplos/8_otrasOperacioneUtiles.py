miLista = [12, 1, -1, 0, 42, -43, 4, 54, 6]

longitud = len(miLista)
print(longitud)

suma = sum(miLista)
print(suma)

minimo = min(miLista)
print(minimo)

maximo = max(miLista)
print(maximo)

nuevaLista = list(range(5))
print(nuevaLista)