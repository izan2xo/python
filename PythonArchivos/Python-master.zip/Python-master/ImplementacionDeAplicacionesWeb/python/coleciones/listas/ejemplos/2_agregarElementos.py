miLista = [1, 2, 3, 4, 5]
print(miLista)

#Agregar un elemento al final de la lista
miLista.append(6)
print(miLista)

#Insertar un elemento en una posición especifica
miLista.insert(1, "uno")
print(miLista)

#Extiende la lista añadiendo varios elementos a la vez
miLista.extend([7, 8, 9])
print(miLista)