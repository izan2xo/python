#En Python, una lista es una estructura de datos que permite almacenar una
#colección de elementos en un orden específico. Las listas son muy
#versátiles y vienen con una amplia variedad de métodos incorporados que
#facilitan su manipulación. A continuación, se presenta una lista de
#las funciones y métodos más comunes para trabajar con listas en Python:

miLista = [1, 2, 3, 4, 5]

print(miLista)