numeros = [10, 20, 30, 40, 50]

tercer_elemento = numeros[2]

print(tercer_elemento)