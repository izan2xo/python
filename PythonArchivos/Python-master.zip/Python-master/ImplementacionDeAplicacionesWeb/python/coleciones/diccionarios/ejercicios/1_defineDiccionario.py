persona = {"nombre": "andres", "edad": "21"}
print(persona)

persona["ciudad"] = "Madrid"
print(persona)

persona["edad"] = "22"
print(persona)