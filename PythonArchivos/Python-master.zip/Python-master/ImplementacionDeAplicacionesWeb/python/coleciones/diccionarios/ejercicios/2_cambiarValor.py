coche = {"dueño": "andres", "color": "azul"}
print(coche)

coche["ciudad"] = "Madrid"
print(coche)

coche["color"] = "rojo"
print(coche)