miDiccionario = {
    "nombre": "Andres",
    "edad": 21,
    "ciudad": "Madrid"
}

#copy(): crea una copia superficial del diccionario
copiaDiccionario = miDiccionario.copy()
print(copiaDiccionario)

#tambien se puede usar dict()
copiaDiccionari1 = dict(miDiccionario)
print(copiaDiccionari1)