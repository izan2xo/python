miDiccionario = {
    "nombre": "Andres",
    "edad": 21,
    "ciudad": "Madrid"
}

#para modificar el valor de una clave existente
miDiccionario["nombre"] = "Felipe"
print(miDiccionario["nombre"])

#para agregar un valor nuevo al diccionario
miDiccionario["genero"] = "masculino"
print(miDiccionario)