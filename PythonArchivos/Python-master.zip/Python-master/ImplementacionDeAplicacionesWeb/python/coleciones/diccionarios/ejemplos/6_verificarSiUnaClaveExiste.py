miDiccionario = {
    "nombre": "Andres",
    "edad": 21,
    "ciudad": "Madrid"
}

#verificar si una clave existe con el operador in:
existe = "nombre" in miDiccionario
print(existe)
