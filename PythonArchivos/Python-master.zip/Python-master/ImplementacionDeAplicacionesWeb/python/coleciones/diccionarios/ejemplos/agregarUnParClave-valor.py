persona = { "nombre": "ana", 
            "edad": "26",}

print(persona)

persona["ciudad"] = "Barcelona"

print(persona)