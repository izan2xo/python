miDiccionario = {
    "nombre": "Andres",
    "edad": 21,
    "ciudad": "Madrid"
}

#len(): devuelve el numero de pares clave-valor en el diccionario

longitud = len(miDiccionario)
print(longitud)