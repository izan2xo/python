conjunto1 = {1, 2, 3}
conjunto2 = {2, 3, 4}

interseccion = conjunto1 & conjunto2
print(interseccion)

interseccion1 = conjunto1.intersection(conjunto2)
print(interseccion1)
