numeros = {1, 2, 3}
print(numeros)

numeros.add(4)
print(numeros)