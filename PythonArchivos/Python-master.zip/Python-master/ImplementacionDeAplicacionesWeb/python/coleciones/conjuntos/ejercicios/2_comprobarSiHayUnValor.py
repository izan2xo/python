numeros = {1, 2, 3, 4,}
print(numeros)

if 5 in numeros:
    print("el numero 5 si esta")
else:
    print("el numero 5 no esta")