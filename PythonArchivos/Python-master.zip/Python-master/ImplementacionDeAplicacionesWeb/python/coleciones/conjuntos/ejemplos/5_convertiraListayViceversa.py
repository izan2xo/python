#convertir una lista a conjunto
miConjunto = set([1, 2, 2, 3])
print(miConjunto)

#convertir un conjunto a lista
miLista = list(miConjunto)
print(miLista)

