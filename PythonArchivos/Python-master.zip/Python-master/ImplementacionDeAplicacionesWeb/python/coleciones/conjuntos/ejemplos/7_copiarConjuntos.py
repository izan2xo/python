miConjunto = {1, 2, 3, 4, 5}
print(miConjunto)

#copy(): crea una copia superficial del conjunto
copia = miConjunto.copy()
print(copia)    