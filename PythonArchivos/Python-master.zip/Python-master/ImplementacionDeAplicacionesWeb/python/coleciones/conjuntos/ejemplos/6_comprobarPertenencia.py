miConjunto = {1, 2, 3, 4, 5}
print(miConjunto)

#usa el operador in para comprobar si un elemento esta en el conjunto
verdadero = 3 in miConjunto
print(verdadero)

falso = 10 in miConjunto
print(falso)