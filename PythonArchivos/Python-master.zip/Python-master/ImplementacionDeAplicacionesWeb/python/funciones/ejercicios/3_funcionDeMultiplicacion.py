#define la funcion llamada multiplicar que acepte dos parametros y devuelva su producto
#prueba la funcion con diferentes valores

def multiplicar(a, b):
    return a * b

ejemplo1 = multiplicar(5, 5)
print(ejemplo1)

ejemplo2 = multiplicar(5, 10)
print(ejemplo2)