#define una funcion llamada resta que acepte dos parametros y devuelva su diferencia
#prueba la funcion con diferentes valores

def resta(a, b):
    return a - b

prueba1 = resta(10, 5)
print(prueba1)

prueba2 = resta(20, 10)
print(prueba2)