#define una funcion llamada saludo_personalizado que acepte dos parametros: nombre y edad.

def saludo_personalizado(nombre, edad):
    print(f"Hola {nombre} ya tienes {edad} años")

saludo_personalizado("Andres", 21)