# -int : numeros entereos, positivos o negativos.
# ejemplo:
x = 10
y = -5

# -float : numeros decimales.
# ejemplo:
pi = 3.14159

# -complex: numeros complejos (con parte real e imaginaria).
# ejemplo:
z = 2 + 3j

# -bool: valores logicos: True o False.
# ejemplo:
is_active = True
is_active = False

# -str: cadenas de texto.
# ejemplo:
name = "Python"
