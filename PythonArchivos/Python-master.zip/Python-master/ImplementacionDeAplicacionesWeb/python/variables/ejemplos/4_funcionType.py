#Sin embargo es importante conocer cual es el tipo real de los datos que estamos utilizando.
#Es posible conocer el tipo de cualquier variable (y objeto en general) usando la funcion type().

var_1 = 100
print(type(var_1))

var_1 = "abcd"
print(type(var_1))
