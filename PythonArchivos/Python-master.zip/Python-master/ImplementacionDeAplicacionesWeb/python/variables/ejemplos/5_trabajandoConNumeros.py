#En Python existen los siguientes tipos numercios:
# -integer: 10
# -float: 10.0
# -complex 10+10j

#Asi es como se realizan operaciones matematicas sencillas con Python:

#Suma
a = 5
b = 10
resultado = a + b
print(resultado)

#Resta
a = 10
b = 5
resultado = a - b
print(resultado)

#Multiplicacion
a = 10 
b = 5
resultado = a * b
print(resultado)

#Division
a = 10
b = 5
resultado = a / b
print(resultado)

#Potencia
a = 10
b = 2
resultado = a ** b
print(resultado)

#Modulo (resto de la division)
a = 10
b = 3
resultado = a % b
print(resultado)
