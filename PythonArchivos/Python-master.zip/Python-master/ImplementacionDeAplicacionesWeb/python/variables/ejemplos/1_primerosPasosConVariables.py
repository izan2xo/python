#Python es un lenguaje no tipado. Por tanto, no es necesario (ni posible) definir los tipos de datos 
#utilizados al declarar variables.
#En gnereal, en Python las variables se declaran en el momento en ql que éstas vas a usarse, por lo 
#que lo que la declaracion va acompaña del valor que se asigna
# el siguiente es un ejemplo de declaracion de una variable

a = 10
print("'a'vale:")
print(a)
print("")

a = "abcd"
print("Ahora 'a' vale:")
print(a)