# -list: lista ordenada, modificable y que puede contener elementos heterogeneos.
# ejemplo:
numbers = [1, 2, 3, 4, 5]

# -tuple: tupla ordenada, inmutable y que puede contener elementos heterogeneor.
coordinates = (10, 20)

# -dict: diccionarios, que almacenan pares clave-valor.
# ejemplo:
person = {"name": "Andres", "age": 25}
