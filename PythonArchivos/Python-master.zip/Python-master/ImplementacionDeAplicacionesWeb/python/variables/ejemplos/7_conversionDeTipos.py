#si en un expresion aritmetica intervienen diferentes tipos de numero, python convierte
#automaticamente al tipo mas general, segun el siguiente esquema
#**int-> float -> complex**
#tambien es posible convertir tipos de manera explicita mediante castas explicitos,
#con la siguiente forma: {nombre_tipo}(variable)
# Transformacion a entero:
print(int(12.5))
# Transformacion a float:
print(float(12))