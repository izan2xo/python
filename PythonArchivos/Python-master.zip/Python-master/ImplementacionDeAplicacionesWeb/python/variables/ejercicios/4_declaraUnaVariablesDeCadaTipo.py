string = "hola esto es una cadana de texto"
entero = 31
decimal = 10.5
verdadero = True
falso = False

print(type(string))
print(type(entero))
print(type(decimal))
print(type(verdadero))
print(type(falso))