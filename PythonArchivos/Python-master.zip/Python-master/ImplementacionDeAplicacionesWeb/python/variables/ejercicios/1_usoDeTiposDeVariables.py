#crea tres variables: una que guarde tu nombre, otra tu edad y otra tu ciudad.
#imprime los valores con un mensaje como:
#"Hola, mi nombre es [nombre], tengo [edad] años y vivo en [ciudad]"

nombre = input("Introduce tu nombre: ")
edad = int(input("Introduce tu edad: "))
ciudad = input("Introduce tu ciudad: ")

print(f"Hola, mi nombre es {nombre}, tengo {edad} años y vivo en {ciudad}")