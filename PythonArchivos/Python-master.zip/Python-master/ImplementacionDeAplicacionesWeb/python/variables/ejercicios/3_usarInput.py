#Escribe un programa que pida al usuario su nombre y su comida favorita.
#luego imprime un mensaje como:
#"Hola [nombre], me alegra saber que te gusta [comida favorita]"

nombre = input("cual es tu nombre: ")
comidaFavorita = input("cual es tu comida favorita: ")

print(f"Hola {nombre}, me alegra saber que te gusta {comidaFavorita}")
