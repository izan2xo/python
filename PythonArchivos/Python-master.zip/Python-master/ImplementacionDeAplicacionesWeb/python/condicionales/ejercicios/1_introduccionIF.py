# pide al usuario un numero. si el numero es mayor que 10, imprime:
#"el numero es mayor que 10"
#si no, no hagas nada

numero = int(input("escribe un numero: "))

if numero > 10:
    print(f"el {numero} es mayor que 10")