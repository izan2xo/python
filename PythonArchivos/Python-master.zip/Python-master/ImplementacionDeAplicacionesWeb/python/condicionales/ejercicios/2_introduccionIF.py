#pide al usuario su edad. si tiene 18 años o mas, imprime
# "eres mayor de edad"
# si tiene menos de 18 imprimie:
# "eres menor de edad"

numero = int(input("ingrese su edad: "))

if numero >= 18:
    print("eres mayor de edad")
else:
    print("eres menor de edad")