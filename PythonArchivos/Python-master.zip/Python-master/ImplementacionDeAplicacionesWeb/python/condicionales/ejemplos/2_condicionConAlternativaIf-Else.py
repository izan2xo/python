#define un bloque de codigo a ejecutar cuando la condicion es verdadera
#y otro cuando es falsa
# if condicion:
#   codigo si la ejecucion es verdadera
#else:
#   codigo si la condicion es falsa

edad = 16
if edad >= 18:
    print("eres  mayor de edad")
else:
    print("erer menor de edad")