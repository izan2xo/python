#las condiciones pueden incluir operadores:
# 
# operadores de comparacion: ==, !=, <, >, <=, >=
# operadores logicos: and, or, not
# operadores de pertenencia: in, not in 

nombre = "Alice"
edad = 25

if nombre == "Alice" and edad >= 18:
    print("Hola, Alice, puedes ingresar")

