#ejecuta un bloque de codigo si la condicion es verdadera
# if condicion:
#   codigo a ejecutar si la condicion es verdadera

edad = 18
if edad >= 18:
    print("Eres mayor de edad")