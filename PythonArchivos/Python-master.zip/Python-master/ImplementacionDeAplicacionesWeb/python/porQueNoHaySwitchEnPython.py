#Python esta diseñado para ser simple y legibble. Las estructuras if-elif-else cubren
#los casos en los que se usario un switch. Ademas, en python proporciona alternativas mas
#potentes y expresivas, como los diccionarios y las funcionoes de orden superior, que 
#pueden simular o reemplazar un switch de manera eficiente

opcion = 2

if opcion == 1:
    pritn("opcion 1 seleccionada")
elif opcion == 2:
    print("opcion 2 seleccionada")
elif opcion == 3:
    print("opcion 3 seleccionada")
else:
    print("opcion no valida")