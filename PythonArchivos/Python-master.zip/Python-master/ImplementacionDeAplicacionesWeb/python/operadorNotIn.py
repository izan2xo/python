frutas = ["manzana", "banana", "cereza"]
if "pera" not in frutas:
    print("la pera no está en la lista")

print("pera" not in frutas)
print("banana" not in frutas)